
#ifdef WIN32
#include "jsautocfg-win.h"
#else
#include "jsautocfg-mac.h"
#endif 